<!DOCTYPE html>
<html>
    <head>
        <title>Homepage</title>
        <style>
            .div
            {
               width: 250px;  
               margin-left: 575px;
            }
        </style>
    </head>
    <body>
        <?php
            require_once 'header.php';
        ?>
        <div class="div">
        <center><h3>Welcome to our Website!!!</h3>
        <p>World largest Book Store <p></center>
        </div>
    </body> 
</html>